# DirectCAN Firmware Protokoll v3.1

SLCAN/LAWICEL kompatibles Protokoll mit ISO-TP Erweiterung.
Funktioniert mit CANHacker, slcand, und DirectCAN App.

## Verbindung

- **Serial:** 2.000.000 Baud (2 Mbit/s)
- **USB:** CDC (virtueller COM-Port)
- **CAN-Buffer:** 128 Frames

---

## SLCAN Befehle (App → Controller)

Alle Befehle enden mit `\r` (Carriage Return).

### CAN Frames senden

| Befehl | Beschreibung | Format |
|--------|--------------|--------|
| `t` | Standard Frame (11-bit ID) | `t<id:3><len:1><data:hex>` |
| `T` | Extended Frame (29-bit ID) | `T<id:8><len:1><data:hex>` |
| `r` | RTR Frame (11-bit ID) | `r<id:3><len:1>` |
| `R` | RTR Frame (29-bit ID) | `R<id:8><len:1>` |

**Beispiele:**
```
t7DF802010000000000    # Standard: ID=7DF, Len=8, OBD-II Request
T18DAF1108021C001000000  # Extended: ID=18DAF110, Len=8
r7E80                   # RTR: ID=7E8, Len=0
```

### Konfiguration

| Befehl | Beschreibung | Antwort |
|--------|--------------|---------|
| `S0` | 10 kbit/s | `\r` |
| `S1` | 20 kbit/s | `\r` |
| `S2` | 50 kbit/s | `\r` |
| `S3` | 100 kbit/s | `\r` |
| `S4` | 125 kbit/s | `\r` |
| `S5` | 250 kbit/s | `\r` |
| `S6` | 500 kbit/s (Default) | `\r` |
| `S7` | 800 kbit/s | `\r` |
| `S8` | 1000 kbit/s | `\r` |
| `O` | CAN Bus öffnen | `\r` |
| `C` | CAN Bus schließen | `\r` |
| `K1` | Loopback aktivieren | `\r` |
| `K0` | Loopback deaktivieren | `\r` |

### Status/Info

| Befehl | Beschreibung | Antwort |
|--------|--------------|---------|
| `V` | Firmware Version | `V3100\r` |
| `N` | Seriennummer | `N0001\r` |
| `F` | Status Flags (hex) | `Fxx\r` |
| `I` | Capabilities (JSON) | `{"fw":"DirectCAN","ver":"3.1","isotp":true,"slcan":true}\r` |

### Status Flags (F-Befehl)

| Bit | Bedeutung |
|-----|-----------|
| 0 | RX Buffer Overflow / Fehler |
| 1 | TX Error |
| 2 | Data Overrun |

---

## Empfangene CAN-Frames (Controller → App)

Gleiche Formate wie Senden, gesendet mit `\r` am Ende:

```
t7E8804410C1AF8000000    # Standard Frame empfangen
T18DAF1100810144902015756  # Extended Frame empfangen
r7E80                     # RTR Frame empfangen
R18DAF1100                # Extended RTR empfangen
```

| Format | Beschreibung |
|--------|--------------|
| `t<id:3><len:1><data>` | Standard Frame (11-bit) |
| `T<id:8><len:1><data>` | Extended Frame (29-bit) |
| `r<id:3><len:1>` | RTR Frame (11-bit) |
| `R<id:8><len:1>` | RTR Frame (29-bit) |

---

## ISO-TP Erweiterung

ISO-TP (ISO 15765-2) für Nachrichten > 8 Bytes (z.B. OBD-II Multi-Frame).

### ISO-TP Senden

| Befehl | Beschreibung | Format |
|--------|--------------|--------|
| `U` | ISO-TP Standard ID | `U<txid:3><rxid:3><len:2><data:hex>` |
| `W` | ISO-TP Extended ID | `W<txid:8><rxid:8><len:4><data:hex>` |

**Beispiel OBD-II VIN-Anfrage:**
```
U7DF7E80209    # TX=7DF, RX=7E8, Len=2, Data=09 02 (Request VIN)
```

### ISO-TP Antwort

**Erfolg:**
```
u<rxid><len:4><data:hex>\r
```

**Fehler:**
```
uERR:NOT_OPEN\r    # CAN nicht geöffnet
uERR:FORMAT\r      # Falsches Befehlsformat
uERR:TOO_LONG\r    # Daten > 4095 Bytes
uERR:DATA_LEN\r    # Datenlänge stimmt nicht
uERR:NO_SLOT\r     # Keine freie RX-Session
uERR:SEND\r        # Senden fehlgeschlagen
uERR:RX_FAIL\r     # Empfang fehlgeschlagen
uERR:TIMEOUT\r     # Timeout (1000ms)
uERR:MULTI_TX_NOT_IMPL\r  # Multi-Frame TX nicht implementiert
```

**Beispiel VIN-Antwort:**
```
u7E80011574155424E5A5A5A5A5A5A5A5A5A5A5A5A
# RX=7E8, Len=17 (0x0011), Data=VIN String
```

### ISO-TP Konfiguration

| Parameter | Wert |
|-----------|------|
| Max Datengröße | 4095 Bytes |
| Timeout | 1000 ms |
| RX Sessions | 4 gleichzeitig |

### ISO-TP Frame Types (intern)

| Type | PCI | Beschreibung |
|------|-----|--------------|
| SF | 0x0X | Single Frame (≤7 Bytes) |
| FF | 0x1X | First Frame (Multi-Frame Start) |
| CF | 0x2X | Consecutive Frame |
| FC | 0x3X | Flow Control |

---

## Antwort-Codes

| Antwort | Bedeutung |
|---------|-----------|
| `\r` | OK / Erfolg |
| `\a` (Bell, 0x07) | Fehler / Unbekannter Befehl |

---

## Beispiel-Session

```bash
# Terminal öffnen
screen /dev/ttyACM0 2000000

# Firmware Info
I
{"fw":"DirectCAN","ver":"3.1","isotp":true,"slcan":true}

# Baudrate setzen (500k)
S6

# CAN öffnen
O

# OBD-II: Supported PIDs anfragen
t7DF802010000000000
# Antwort: t7E8804410CBE3FA813

# ISO-TP: VIN anfragen
U7DF7E80209
# Antwort: u7E80011574155424E...

# CAN schließen
C
```

---

## Timing

- **CAN-Buffer:** 128 Frames
- **ISO-TP Timeout:** 1000 ms
- **Serial Baudrate:** 2.000.000 Baud

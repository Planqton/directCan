#!/bin/bash
# Flash Script für Feather M4 CAN Firmware
# Verwendet arduino-cli

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKETCH="$SCRIPT_DIR/feather_m4_can_firmware.ino"
BOARD="adafruit:samd:adafruit_feather_m4_can"

# Farben für Output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Feather M4 CAN Firmware Flash Script ===${NC}"
echo ""

# Funktion: arduino-cli installieren
install_arduino_cli() {
    echo -e "${YELLOW}Installiere arduino-cli...${NC}"

    # Version und Download URL
    VERSION=$(curl -s https://api.github.com/repos/arduino/arduino-cli/releases/latest | grep -oP '"tag_name":\s*"\K[^"]+')
    VERSION_NUM="${VERSION#v}"  # Remove 'v' prefix
    DOWNLOAD_URL="https://github.com/arduino/arduino-cli/releases/download/${VERSION}/arduino-cli_${VERSION_NUM}_Linux_64bit.tar.gz"

    echo "Lade arduino-cli ${VERSION} herunter..."

    mkdir -p ~/.local/bin
    cd /tmp
    curl -fsSL -o arduino-cli.tar.gz "$DOWNLOAD_URL"
    tar -xzf arduino-cli.tar.gz
    mv arduino-cli ~/.local/bin/
    rm arduino-cli.tar.gz
    cd - > /dev/null

    export PATH="$PATH:$HOME/.local/bin"

    # Zu bashrc hinzufügen falls nicht bereits vorhanden
    if ! grep -q 'local/bin' ~/.bashrc 2>/dev/null; then
        echo 'export PATH="$PATH:$HOME/.local/bin"' >> ~/.bashrc
    fi

    echo -e "${GREEN}arduino-cli ${VERSION} installiert!${NC}"
}

# Prüfe ob arduino-cli installiert ist
if ! command -v arduino-cli &> /dev/null; then
    echo -e "${YELLOW}arduino-cli nicht gefunden.${NC}"
    read -p "Soll arduino-cli installiert werden? (j/n): " install_choice
    if [[ "$install_choice" == "j" || "$install_choice" == "J" ]]; then
        install_arduino_cli
    else
        echo -e "${RED}arduino-cli wird benötigt. Abbruch.${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}arduino-cli gefunden: $(which arduino-cli)${NC}"
echo ""

# Adafruit Board Index hinzufügen
echo -e "${YELLOW}Konfiguriere Board-Index...${NC}"
arduino-cli config init --overwrite 2>/dev/null || true
arduino-cli config add board_manager.additional_urls https://adafruit.github.io/arduino-board-index/package_adafruit_index.json

# Core installieren
echo -e "${YELLOW}Installiere Adafruit SAMD Core...${NC}"
arduino-cli core update-index
arduino-cli core install adafruit:samd

# CANSAME5x Library installieren
echo -e "${YELLOW}Installiere CANSAME5x Library...${NC}"
arduino-cli lib install "Adafruit CAN"

echo ""
echo -e "${GREEN}Setup abgeschlossen!${NC}"
echo ""

# Verfügbare Ports anzeigen
echo -e "${YELLOW}Suche nach angeschlossenen Boards...${NC}"
arduino-cli board list

echo ""

# Port auswählen
PORTS=$(arduino-cli board list --format json 2>/dev/null | grep -oP '"address":\s*"\K[^"]+' || true)

if [ -z "$PORTS" ]; then
    echo -e "${YELLOW}Kein Board automatisch erkannt.${NC}"
    echo "Bekannte Ports:"
    ls /dev/ttyACM* /dev/ttyUSB* 2>/dev/null || echo "  Keine seriellen Ports gefunden"
    echo ""
    read -p "Port eingeben (z.B. /dev/ttyACM0) oder Enter für Auto-Detect: " PORT
else
    # Ersten Port als Default verwenden
    DEFAULT_PORT=$(echo "$PORTS" | head -1)
    read -p "Port eingeben (Default: $DEFAULT_PORT): " PORT
    PORT=${PORT:-$DEFAULT_PORT}
fi

if [ -z "$PORT" ]; then
    echo -e "${RED}Kein Port angegeben. Abbruch.${NC}"
    exit 1
fi

echo ""
echo -e "${YELLOW}Kompiliere Firmware...${NC}"
arduino-cli compile --fqbn "$BOARD" "$SKETCH" --verbose

echo ""
echo -e "${YELLOW}Flashe Firmware auf $PORT...${NC}"
arduino-cli upload -p "$PORT" --fqbn "$BOARD" "$SKETCH" --verbose

echo ""
echo -e "${GREEN}=== Firmware erfolgreich geflasht! ===${NC}"
echo ""
echo "Hinweise:"
echo "  - Serial Baudrate: 2000000"
echo "  - Default CAN Baudrate: 500000"
echo "  - Protokoll: Text-Modus (default)"
